using System.Windows;

namespace LibrarySelfService
{
    public partial class App : Application
    {
    }
}
