using System.Windows;
using System.Windows.Controls;

namespace LibrarySelfService
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            MainFrame.Navigate(new Pages.MainPage(MainFrame));
        }
    }
}
